import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Particle extends Actor
{
    private int life;
    private int initialLife; // Vida inicial da partícula
    private int maxSize = 20; // Tamanho máximo da partícula

    public Particle(int life)
    {
        this.life = life;
        this.initialLife = life;
        GreenfootImage image = new GreenfootImage(maxSize, maxSize);
        image.setColor(Color.RED);
        image.fillOval(0, 0, maxSize, maxSize);
        setImage(image);
    }

    public void act()
    {
        // Reduz a vida da partícula
        if (life > 0)
        {
            life--;
        }
        else
        {
            getWorld().removeObject(this); // Remove a partícula quando a vida chega a zero
        }
        
        // Ajusta a opacidade da partícula com base na vida
        int opacity = (int) (255 * ((double) life / initialLife));
        GreenfootImage image = getImage();
        image.setTransparency(opacity);
        setImage(image);
    }
}