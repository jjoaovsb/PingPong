import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PongWorld extends World
{
    private Ball ball;
    private Paddle leftPaddle;
    private Paddle rightPaddle;
    private LeftScore leftScore;
    private RightScore rightScore;
    private boolean isGameStarted;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public PongWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        isGameStarted = false;
        
        // Add start button to the world
        addObject(new StartButton(), getWidth() / 2, getHeight() / 3);
        addObject(new SkinButton(), getWidth() / 2, getHeight() / 2);
    }
    
    public void startGame()
    {
        isGameStarted = true;
        
        // Add paddles to the world
        leftPaddle = new Paddle(true);
        rightPaddle = new Paddle(false);
        addObject(leftPaddle, 50, getHeight() / 2);
        addObject(rightPaddle, getWidth() - 50, getHeight() / 2);
        
        // Add ball to the world
        ball = new Ball();            
        addObject(ball, getWidth() / 2, getHeight() / 2);
        
        // Left and right scores
        leftScore = new LeftScore();
        addObject(leftScore, getWidth()/2 - 120, 48);
        rightScore = new RightScore();
        addObject(rightScore, getWidth()/2 + 120, 48);
        
        removeObjects(getObjects(StartButton.class));
        removeObjects(getObjects(SkinButton.class));
    }
    
    public void selectskin()
    {
        // Add paddles to the world
        rightPaddle = new Paddle(false);
        addObject(rightPaddle, getWidth() - 50, getHeight() / 2);
        
        // Add ball to the world
        ball = new Ball();            
        addObject(ball, 500, getHeight() / 2);
        
        removeObjects(getObjects(StartButton.class));
        removeObjects(getObjects(SkinButton.class));
        
        addObject(new CorBolaum(), 75, 50);
        addObject(new CorBoladois(), 75, 120);
        addObject(new CorBolatres(), 75, 190);
        
        addObject(new Cortacoum(), 275, 50);
        addObject(new Cortacodois(), 275, 120);
        addObject(new Cortacotres(), 275, 190);
    }
    
    public Ball getBall()
    {
        return this.ball;
    }
    
    public LeftScore getLeftScore()
    {
        return this.leftScore;
    }
    
    public RightScore getRightScore()
    {
        return this.rightScore;
    }
    
    public boolean isGameStarted()
    {
        return isGameStarted;
    }
}
