import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Ball extends Actor
{
    private GreenfootSound hitSound; // Efeito sonoro do contato com a raquete
    private double xSpeed = 3;
    private double ySpeed = 3;
    private int hitCount = 0; // Contador de rebatidas
    private static final double SPEED_INCREMENT = 0.5; // Incremento de velocidade reduzido

    /* 
     * Constructor
     */
    public Ball()
    {
        GreenfootImage image = new GreenfootImage(16, 16);
        image.setColor(Color.RED);
        image.fillOval(0, 0, 16, 16);
        setImage(image);
        
        // Carrega o efeito sonoro
        hitSound = new GreenfootSound("hitBall.mp3"); // Substitua "hitSound.wav" pelo nome do seu arquivo de áudio
    }

    public void act()
    {
        PongWorld world = (PongWorld) getWorld();
        if (world.isGameStarted())
        {
            move();
            checkCollision();
            leaveTrail(); // Adiciona partículas na trajetória da bola           
        }
    }

    private void move()
    {
        PongWorld world = (PongWorld) getWorld();
        Score score = null;
        
        setLocation((int)(getX() + xSpeed), (int)(getY() + ySpeed));
        
        if (getY() <= 0 || getY() >= world.getHeight() - 1)
        {
            ySpeed = -ySpeed;
        }
        
        if (getX() <= 0)
        {
            score = world.getRightScore();
        }
        
        if (getX() >= world.getWidth() - 1)
        {
            score = world.getLeftScore();
        }
        
        if (score != null)
        {
            score.add();
            score.update();
            resetSpeed(); // Chama o método para resetar a velocidade
            resetPosition();
        }
    }

    private void checkCollision()
    {
        if (isTouching(Paddle.class))
        {
            xSpeed = -xSpeed;
            hitCount++; // Incrementa o contador de rebatidas
            increaseSpeedIfNecessary(); // Verifica e aumenta a velocidade se necessário
            showCollisionEffect(); // Adiciona partículas durante a colisão
            playHitSound(); // Reproduz o efeito sonoro
        }
    }

    private void increaseSpeedIfNecessary()
    {
        // Incrementa a velocidade a cada 5 rebatidas (ajuste conforme necessário)
        if (hitCount % 5 == 0)
        {
            xSpeed += xSpeed > 0 ? SPEED_INCREMENT : -SPEED_INCREMENT;
            ySpeed += ySpeed > 0 ? SPEED_INCREMENT : -SPEED_INCREMENT;
        }
    }

    private void resetPosition()
    {
        setLocation(getWorld().getWidth() / 2, getWorld().getHeight() / 2);
        hitCount = 0; // Reseta o contador de rebatidas
    }

    private void resetSpeed()
    {
        // Método para resetar a velocidade ao marcar um ponto
        xSpeed = Greenfoot.getRandomNumber(2) == 0 ? 3 : -3;
        ySpeed = Greenfoot.getRandomNumber(2) == 0 ? 3 : -3;
    }

    private void leaveTrail()
    {
        getWorld().addObject(new Particle(20), getX(), getY());
    }

    private void showCollisionEffect()
    {
        for (int i = 0; i < 10; i++)
        {
            int xOffset = Greenfoot.getRandomNumber(20) - 10;
            int yOffset = Greenfoot.getRandomNumber(20) - 10;
            getWorld().addObject(new Particle(30), getX() + xOffset, getY() + yOffset);
        }
    }

    private void playHitSound()
    {
        if (hitSound != null)
        {
            hitSound.play();
        }
    }
}