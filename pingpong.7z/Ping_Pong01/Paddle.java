import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Paddle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Paddle extends Actor
{
    private boolean isLeft;

    public Paddle(boolean isLeft)
    {
        this.isLeft = isLeft;
        GreenfootImage image = new GreenfootImage(10, 60);
        image.setColor(Color.WHITE);
        image.fill();
        setImage(image);
    }

    public void act()
    {
        // Movement for left paddle
        if (isLeft)
        {
            if (Greenfoot.isKeyDown("w")) moveUp();
            if (Greenfoot.isKeyDown("s")) moveDown();
        }
        // Movement for right paddle
        else
        {
            if (Greenfoot.isKeyDown("up")) moveUp();
            if (Greenfoot.isKeyDown("down")) moveDown();
        }
    }

    private void moveUp()
    {
        if (getY() > 30) setLocation(getX(), getY() - 6);
    }

    private void moveDown()
    {
        if (getY() < getWorld().getHeight() - 30) setLocation(getX(), getY() + 6);
    }
}
